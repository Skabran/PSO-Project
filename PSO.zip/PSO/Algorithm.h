#ifndef ALGORITHM_H_INCLUDED
#define ALGORITHM_H_INCLUDED
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>

#include "solution.h"
#include "SetUpParams.h"
using std::vector;
  class Algorithm
  {
	private:
		vector<Solution*> d_population;     // individuals in population
		vector<double> d_fitness_values_of_current_population;
		const SetUpParams& d_setup;
		Solution* d_global_best_solution;

	public:
		Algorithm(const Problem& pbm,const SetUpParams& setup);
		~Algorithm();

		const SetUpParams& setup() const;
	  	void initialize();

		// evaluate the current population
        void evaluate();

	 	const vector<Solution*>& current_solutions() const;

		double global_best_cost() const;

		Solution& solution(const unsigned int index) const;

		Solution& global_best_solution() const;

		// main loop of the algorithm
		void evolution();

  };

#endif // ALGORITHM_H_INCLUDED

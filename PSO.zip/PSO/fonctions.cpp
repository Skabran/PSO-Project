#include "fonctions.h"

#include <cmath>
#include <iostream>




double fonctions::BentCigar(vector<double> &solution)
{
    double X1Carre = solution[0] * solution[0] ; // x1�
    double Somme = 0 ;
    for (int i = 1; i < solution.size(); i++)
    {
        Somme += solution[i] * solution[i];
    }
    return X1Carre + 1000000 * Somme;
}


double fonctions::Discus(vector<double> &solution)
{
    double X1Carre = solution[0] * solution[0]; // x1�
    double Somme = 0;
    for (int i = 1; i < solution.size(); i++)
    {
        Somme += solution[i] * solution[i];
    }
    return 1000000 * X1Carre + Somme;
}


double SousSommeWeierstrass(double x, double a,double b, int kmax)
{
    double Somme {0};
    for (int k = 0; k < kmax; k++)
    {
        Somme += pow( a, k) * cos(2 * PI * pow(b,k) * ( x + 0.5));
    }
    return Somme;
}


double fonctions::Weierstrass(vector<double> &solution)
{
    double a=0.5,b=3;
    int kmax=20;
    double Somme {0};
    for (int i = 0; i < solution.size(); i++)
    {
        Somme += SousSommeWeierstrass( solution[i] , a , b , kmax ) - solution.size() * SousSommeWeierstrass( 0.0 , a , b , kmax );
    }
    return Somme;
}


double SousSommeKatsuura ( double x)
{
    double somme = 0.0;
    double deuxPuissanceJ = 1;
    for (int j = 1; j <= 32; j++)
    {
        deuxPuissanceJ *= 2;
        somme += ( abs( deuxPuissanceJ * x - round( deuxPuissanceJ * x )) / deuxPuissanceJ);
    }
    return somme ;
}


double fonctions::Katsuura(vector<double> &solution)
{
    double produit = 1.1;
    double dixSurDCarre = 10 / (solution.size() * solution.size()) ;
    double exposantDeLaMultiplication = 10/pow(solution.size(),1.2) ;
    for( int i = 0 ; i < solution.size(); ++i)
    {
        produit *= pow(1 + i * SousSommeKatsuura( solution[i]), exposantDeLaMultiplication);
    }
    return dixSurDCarre * produit - dixSurDCarre;
}


double sousSommeSimple(vector<double> &solution)
{
    double somme = 0.0;
    for(int i = 0; i < solution.size(); i++)
    {
        somme += solution[i];
    }
    return somme;
}


double sousSommeCarre(vector<double> &solution)
{
    double somme = 0.0;
    for(int i = 0; i < solution.size(); i++)
    {
        somme += solution[i] * solution[i];
    }
    return somme;
}


double fonctions::HappyCat(vector<double> &solution)
{
    double sommeCarre = sousSommeCarre( solution );
    double sommeSimple = sousSommeCarre ( solution );
    double premierSousResultat = pow ( abs ( sommeCarre - solution.size() ) , 0.25 /* =1/4*/ );
    double sommeDesSommes = 0.5 * sommeCarre + sommeSimple;
    double deuxiemeSousResultat = sommeDesSommes - ( solution.size() + 0.5 );
    return premierSousResultat + deuxiemeSousResultat ;
}


double fonctions::HGBat (vector<double> &solution)
{
    double sommeCarre = sousSommeCarre( solution );
    double sommeSimple = sousSommeSimple ( solution );
    double sommeCarreCarre = sommeCarre * sommeCarre;
    double sommeSimpleCarre = sommeSimple * sommeSimple;
    double valeurAbsolue = abs(sommeCarreCarre - sommeSimpleCarre);
    double deuxiemeParenthese = sommeCarre / 2 + sommeSimple;
    return pow( valeurAbsolue , 0.5 ) + deuxiemeParenthese / solution.size() + 0.5;
}



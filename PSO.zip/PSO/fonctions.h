#ifndef FONCTIONS_H_INCLUDED
#define FONCTIONS_H_INCLUDED
#include <vector>
using std::vector;
const double PI = 3.14159265358979323846;



class fonctions{

public:
    static double BentCigar(vector<double> &solution);
    static double Discus(vector<double> &solution);
    static double Weierstrass(vector<double> &solution);
    static double Katsuura(vector<double> &solution);
    static double HappyCat( vector<double> &solution);
    static double HGBat( vector<double> &solution);



};

#endif // FONCTIONS_H_INCLUDED

#include "solution.h"

Solution::Solution(const Problem& pbm):d_pbm{pbm}
{

}

Solution::Solution(const Solution& sol):d_solution{sol.d_solution},d_fitness_current{sol.d_fitness_current},d_pbm{sol.d_pbm}
{

}

Solution::~Solution()
{

}

const Problem& Solution::pbm() const
{
    return d_pbm;
}

void Solution::initialize()
{
    int randomN = rand();
    int dimension = d_solution.size();
    int upperBound = (d_pbm.UpperBound() - d_pbm.LowerBound()) + 1;
    for(int i=0; i<dimension; i++)
    {
        d_solution[i]=(randomN%upperBound)+d_pbm.LowerBound();
    }
}

void Solution::fitness()
{

    switch(d_pbm.d_numfonction)
    {
        case BENT_CIGAR :   d_fitness_current = fonctions::BentCigar(d_solution);

        case DISCUS : d_fitness_current = fonctions::Discus(d_solution);

        case WEIERSTRASS : d_fitness_current = fonctions::Weierstrass(d_solution);

        case KATSUURA : d_fitness_current = fonctions::Katsuura(d_solution);

        case HAPPYCAT : d_fitness_current = fonctions::HappyCat(d_solution);

        case HGBAT : d_fitness_current = fonctions::HGBat(d_solution);

    }

}

double Solution::get_fitness()
{
    return d_fitness_current;
}

vector<double>& Solution::get_solution()
{
    return d_solution;
}

double& Solution::get_position_in_solution(const int index)
{
    return d_solution[index];
}

void  Solution::set_position_in_solution(const int index, const double value)
{
    d_solution[index]=value;
}

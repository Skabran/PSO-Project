#include "Problem.h"

Problem::Problem(int numfonction):d_numfonction{numfonction}, d_dimension{DIM_PROBLEME}
{
    switch (numfonction)
    {
        case BENT_CIGAR : d_LowerBound = -100;d_UpperBound = 100;
        case DISCUS : d_LowerBound = -5;d_UpperBound = 5;
        case WEIERSTRASS : d_LowerBound = -0.5;d_UpperBound = 0.5;
        case KATSUURA : d_LowerBound = 0;d_UpperBound = 100;
        case HAPPYCAT : d_LowerBound = -2;d_UpperBound = 2;
        case HGBAT : d_LowerBound = -5;d_UpperBound = 5;
    }
}

int Problem::dimension()const
{
    return d_dimension;
}

double Problem::LowerBound()const
{
    return d_LowerBound;
}

double Problem::UpperBound()const
{
    return d_UpperBound;
}

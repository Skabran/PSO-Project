#ifndef PROBLEM_H_INCLUDED
#define PROBLEM_H_INCLUDED
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include "fonctions.h"
const int NB_EXECUTIONS = 30;
const int DIM_PROBLEME = 20;
const int INDIVIDUS_DANS_POP = 40;
const double APPELS_FONCTION_OBJECTIFS = 20000;

const int BENT_CIGAR = 1;
const int DISCUS = 2;
const int WEIERSTRASS = 3;
const int KATSUURA = 4;
const int HAPPYCAT = 5;
const int HGBAT = 6;

class Problem
{
	public:
		Problem(int numfonction);
		~Problem();
		int dimension() const;
        double LowerBound()const;
        double UpperBound()const;
		int d_numfonction;

	private:

		int d_dimension;
		double d_LowerBound, d_UpperBound;
};


#endif // PROBLEM_H_INCLUDED

#include "Algorithm.h"

Algorithm::Algorithm(const Problem& pbm,const SetUpParams& setup):d_setup{setup}
{

}

const SetUpParams& Algorithm::setup() const
{
    return d_setup;
}

void Algorithm::initialize()
{

}

void Algorithm::evaluate()
{

}

const vector<Solution*>& Algorithm::current_solutions() const
{
    return d_population;
}

double Algorithm::global_best_cost() const
{

}

Solution& Algorithm::solution(const unsigned int index) const
{
    return *d_population[index];
}

Solution& Algorithm::global_best_solution() const
{
    return *d_global_best_solution;
}

void Algorithm::evolution()
{

}
